# -*- coding: utf-8 -*-
"""
Created on Wed Mar  6 18:09:16 2024

@author: C2
"""
from data import Data
import json


data = Data()
sor = data.get_stop_of_route("Taoyuan","L609")
rtns = data.get_real_time_near_stop("Taoyuan","L609")

with open("./data/route.json",'w') as f:
    json.dump(sor, f)

with open("./data/location.json",'w') as f:
    json.dump(rtns, f)

forward = 
backward = 

print("順向:")

print("逆向:")

